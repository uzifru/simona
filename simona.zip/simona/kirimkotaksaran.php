<?php 
    session_start(); 
    include"config/config.php";
    if(isset($_POST['kirim'])){
        if ($_SESSION['catcha_text'] != $_POST['captcha']) {
            echo "<script>alert('captcha code salah ! , coba lagi..');</script>";
        }else{
            $nama = $_POST['nama'];
            $email = $_POST['email'];
            $pesan = $_POST['pesan'];
            $con->query("insert into kotak_saran set
            nama = '$nama',
            email = '$email',
            saran = '$pesan'
        ");
        echo "<script>alert('Terimakasih Telah Mengirimkan Pesan');</script>";
        }
    }
     echo "<meta http-equiv='refresh' content='1;url=index.php'>";
?>