<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">

  <title>Peta Covid-19 SIMONA</title>
  <meta content="" name="descriptison">

  <!-- Favicons -->
  <link href="assets/img/fav.png" rel="icon">
  <link href="assets/img/favicon1.png" rel="apple-touch-icon">

  <!-- Google Fonts -->
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Roboto:300,300i,400,400i,500,500i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">

  <!-- Vendor CSS Files -->
  <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/vendor/icofont/icofont.min.css" rel="stylesheet">
  <link href="assets/vendor/boxicons/css/boxicons.min.css" rel="stylesheet">
  <link href="assets/vendor/owl.carousel/assets/owl.carousel.min.css" rel="stylesheet">
  <link href="assets/vendor/venobox/venobox.css" rel="stylesheet">
  <link href="assets/vendor/aos/aos.css" rel="stylesheet">

  <!-- Template Main CSS File -->
  <link href="assets/css/style.css" rel="stylesheet">
</head>
<body>

  <!-- ======= Header ======= -->
  <header id="header" class="fixed-top header-inner-pages">
    <div class="container-fluid">
      <div class="row justify-content-center">
        <div class="col-xl-9 d-flex align-items-center">
          <a href="index.html" class="logo mr-auto">
            <img src="assets/img/logo1.png" alt="" class="img-fluid">
          </a>
          <!-- Nav menu -->
          <nav class="nav-menu d-none d-lg-block">
            <ul>
              <li><a href="index.php">Home</a></li>
              <li><a href="datacovid.php">Data</a></li>
              <li><a href="donasicovid.php">Donasi</a></li>
            </ul>
          </nav><!-- .nav-menu -->
      </div>
    </div>
  </header><!-- End Header -->

  <main id="main">

    <!-- ======= Breadcrumbs ======= -->
    <section id="breadcrumbs" class="breadcrumbs">
      <div class="container">
        <div class="d-flex justify-content-between align-items-center">       
          <ol>
            <li><a href="index.php">Home</a></li>
            <li>Peta Persebaran COVID-19</li>
          </ol>
        </div>
      </div>
    </section> <!-- End Breadcrumbs -->    

    <section id="portfolio-details" class="portfolio-details">
      <div class="container" data-aos="fade-up">

        <div class="row mt-4">
          <div class="col-md-6 mt-3">
            <div class="card"
              style="border-top: 2px solid #2ba3af;
              transition: all ease-in-out 0.3s;
              box-shadow: 0px 0 25px 0 rgba(0, 0, 0, 0.1);">
              <iframe src="https://public.domo.com/cards/bWxVg" width="100%" height="500" marginheight="0" marginwidth="0" frameborder="0"></iframe>
            </div>
          </div>

          <div class="col-md-6 mt-3">
            <div class="card"
              style="border-top: 2px solid #2ba3af;
              transition: all ease-in-out 0.3s;
              box-shadow: 0px 0 25px 0 rgba(0, 0, 0, 0.1);">
              <iframe src="https://public.domo.com/cards/aMk4Q" width="100%" height="500" marginheight="0" marginwidth="0" frameborder="0"></iframe>
            </div>
          </div>
        </div>

        <div class="row mt-4">
          <div class="col-md-6 mt-3">
            <div class="card"
              style="border-top: 2px solid #2ba3af;
              transition: all ease-in-out 0.3s;
              box-shadow: 0px 0 25px 0 rgba(0, 0, 0, 0.1);">
              <iframe src="https://public.domo.com/cards/dNl4L" width="100%" height="600" marginheight="0" marginwidth="0" frameborder="0"></iframe>
            </div>
          </div>

          <div class="col-md-6 mt-3">
            <div class="card"
              style="border-top: 2px solid #2ba3af;
              transition: all ease-in-out 0.3s;
              box-shadow: 0px 0 25px 0 rgba(0, 0, 0, 0.1);">
              <iframe src="https://public.domo.com/cards/aKg4r" width="100%" height="600" marginheight="0" marginwidth="0" frameborder="0"></iframe>
            </div>
          </div>
        </div>

      </div> <!-- /.container -->
    </section>

  </main><!-- End #main -->

 <!-- ======= Footer ======= -->
  <footer id="footer">

    <div class="container">

      <div class="copyright-wrap d-md-flex py-4">
        <div class="mr-md-auto text-center text-md-left">
          <div class="copyright">
            <img src="assets/img/logo1.png" alt="simona" class="img-fluid" width="190px;">
          </div>
        </div>
        <div class="mr-md-auto text-center text-md-center mt-2">
          <div class="copyright">
            &copy; Copyright <strong><span>SIMONA</span></strong>. All Rights Reserved
          </div>
          <div class="credits">
            Designed by <a href="https://instagram.com/uzifru">UZIFRU</a>
          </div>
        </div>
        <div class="social-links text-center text-md-right pt-3 pt-md-0">
          <a href="https://twitter.com/uzifru1" target="_BLANK" class="twitter">
            <i class="bx bxl-twitter"></i>
          </a>
          <a href="https://facebook.com/uzifru.on" target="_BLANK" class="facebook">
            <i class="bx bxl-facebook"></i>
          </a>
          <a href="https://instagram.com/uzifru" target="_BLANK" class="instagram">
            <i class="bx bxl-instagram"></i>
          </a>
          <a href="https://api.whatsapp.com/send?phone=682217459587&text=Assalamualaikum%20Fauzi" target="_blank" class="google-plus">
            <i class="bx bxl-whatsapp"></i>
          </a>
          <a href="https://www.linkedin.com/in/fauzi-rizky-utama-82473a19a/" target="_BLANK" class="linkedin">
            <i class="bx bxl-linkedin"></i>
          </a>
        </div>
      </div>

    </div>
  </footer><!-- End Footer -->

  <a href="#" class="back-to-top"><i class="icofont-simple-up"></i></a>
  <div id="preloader"></div>

  <div class="preloader">
    <div class="loading">
      <img src="assets/img/1.gif" width="400">
    </div>
  </div>

  <!-- Vendor JS Files -->
  <script src="assets/vendor/jquery/jquery.min.js"></script>
  <script>
      $(document).ready(function(){
        $(".preloader").delay(400).fadeOut("slow");
      })
  </script>
  <script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="assets/vendor/jquery.easing/jquery.easing.min.js"></script>
  <script src="assets/vendor/php-email-form/validate.js"></script>
  <script src="assets/vendor/waypoints/jquery.waypoints.min.js"></script>
  <script src="assets/vendor/counterup/counterup.min.js"></script>
  <script src="assets/vendor/owl.carousel/owl.carousel.min.js"></script>
  <script src="assets/vendor/isotope-layout/isotope.pkgd.min.js"></script>
  <script src="assets/vendor/venobox/venobox.min.js"></script>
  <script src="assets/vendor/aos/aos.js"></script>

  <!-- Template Main JS File -->
  <script src="assets/js/main.js"></script>

</body>

</html>