<?php 
    session_start(); 
    include"config/config.php";
    if(isset($_POST['kirim'])){
        if ($_SESSION['catcha_text'] != $_POST['captcha']) {
            echo "<script>alert('captcha code salah ! , coba lagi..');</script>";
        }else{
            $nama = $_POST['nama'];
            $nohp = $_POST['nohp'];
            $email = $_POST['email'];
            $lokasi_file = $_FILES['fupload']['tmp_name'];
            $nama_file   = $_FILES['fupload']['name'];
            $jumlah = $_POST['jumlah'];
            $catatan = $_POST['catatan'];
            // Tentukan folder untuk menyimpan file
            $folder = "assets/img/bukti/$nama_file";
            // Apabila file berhasil di upload
            if (move_uploaded_file($lokasi_file,"$folder")):
                $query = "INSERT INTO donasi (nama, nohp,email,bukti,jumlah,catatan)
                            VALUES('$nama', '$nohp', '$email' ,'$nama_file','$jumlah', '$catatan')";
                mysqli_query($con, $query);
            endif;
        echo "<script>alert('Terimakasih Telah Mengirimkan Donasi');</script>";
        }
    }
     echo "<meta http-equiv='refresh' content='1;url=donasicovid.php'>";
?>