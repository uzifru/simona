<?php  
  error_reporting(E_ALL^(E_NOTICE|E_WARNING));
?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">

  <title>SIMONA</title>
  <meta content="Sistem Monitoring dan donasi Corona by uzifru" name="descriptison">
  <meta content="" name="keywords">

  <!-- Favicons -->
  <link href="assets/img/fav.png" rel="icon">
  <link href="assets/img/favicon1.png" rel="apple-touch-icon">

  <!-- Google Fonts -->
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Roboto:300,300i,400,400i,500,500i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">

  <!-- Vendor CSS Files -->
  <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/vendor/icofont/icofont.min.css" rel="stylesheet">
  <link href="assets/vendor/boxicons/css/boxicons.min.css" rel="stylesheet">
  <link href="assets/vendor/owl.carousel/assets/owl.carousel.min.css" rel="stylesheet">
  <link href="assets/vendor/venobox/venobox.css" rel="stylesheet">
  <link href="assets/vendor/aos/aos.css" rel="stylesheet">

  <!-- Template Main CSS File -->
  <link href="assets/css/style.css" rel="stylesheet">

</head>

<body>

  <!-- ======= Header ======= -->
  <header id="header" class="fixed-top ">
    <div class="container-fluid">

      <div class="row justify-content-center">
        <div class="col-xl-9 d-flex align-items-center">
          <!-- Uncomment below if you prefer to use an image logo -->
          <a href="index.html" class="logo mr-auto">
            <img src="assets/img/logo1.png" alt="" class="img-fluid">
          </a>

          <nav class="nav-menu d-none d-lg-block">
            <ul>
              <li class="active"><a href="#top">Home</a></li>
              <li><a href="#data">Data</a></li>
              <li><a href="#edukasi">Edukasi</a></li>
              <li><a href="#donasi">Donasi</a></li>
              <li><a href="#faq">FAQ</a></li>
              <li><a href="#contact">Contact</a></li>
            </ul>
          </nav><!-- .nav-menu -->

          <a href="petacovid.php" id="fs"  class="get-started-btn">
            <i class="bx bx-map-alt"></i> Lihat Peta
          </a>


        </div>
      </div>

    </div>
  </header><!-- End Header -->

  <!-- ======= Hero Section ======= -->
  <section id="hero" class="d-flex align-items-center">
    <div class="container-fluid" data-aos="fade-up">
      <div class="row justify-content-center">
        <div class="col-xl-5 col-lg-6 pt-3 pt-lg-0 order-2 order-lg-1 d-flex flex-column justify-content-center">
          <h1>Indonesia Lawan Covid-19</h1>
          <h2>Be Strong, Stay Home Stay Save !</h2>
          <div><a href="#contact" class="btn-get-started scrollto">Nomor Hotline</a></div>
        </div>
        <div class="col-xl-4 col-lg-6 order-1 order-lg-2 hero-img" data-aos="zoom-in" data-aos-delay="150">         
        </div>
      </div>
    </div>
  </section><!-- End Hero -->

  <main id="main">

    <!-- ======= Data Dunia ======= -->
    <section id="data" class="data">
      <div class="container">

        <?php
          $dataa = file_get_contents('https://api.kawalcorona.com/positif');
          $positif = json_decode($dataa, true);

          $datab = file_get_contents('https://api.kawalcorona.com/sembuh');
          $sembuh = json_decode($datab, true);

          $datac = file_get_contents('https://api.kawalcorona.com/meninggal');
          $meninggal = json_decode($datac, true);  
        ?> 

        <div class="row">
          <div class="col-lg-6 order-1 order-lg-2" data-aos="zoom-in" data-aos-delay="150">
            <img src="assets/img/map-coro.png" class="img-fluid animated" alt="">
          </div>    
          <div class="col-lg-6 pt-4 pt-lg-0 order-2 order-lg-1 content" data-aos="fade-right">
            <h3>Persebaran COVID-19 global</h3>
            <p class="font-italic">
              Berikut persebaran COVID-19 di seluruh DUNIA
            </p>      
            <ul> 
              <li>
                <i class="icofont-check-circled"></i> Total Positif : 
                <i style="color: #ff000d;font-size: 30px;" data-toggle="counter-up">
                  <b><?= $positif['value']; ?></b>
                </i>
              </li>
              <li>
                <i class="icofont-check-circled"></i> Total Sembuh : 
                <i style="color: #00a321;font-size: 30px;" data-toggle="counter-up">
                  <b><?= $sembuh['value']; ?></b>
                </i>
              </li>
              <li>
                <i class="icofont-check-circled"></i> Total Meninggal : 
                <i style="color: #e9ff00;font-size: 30px;" data-toggle="counter-up">
                  <b><?= $meninggal['value']; ?></b>
                </i>
              </li>     
            </ul>
            
            <a href="datacovid.php" class="read-more">Lihat Detail <i class="icofont-long-arrow-right"></i></a>

          </div>     
        </div>
      </div>
    </section><!-- /.Data -->

    <!-- ======= Counts ======= -->
    <section id="counts" class="counts">
      <div class="container">
        <?php  
          $datad = file_get_contents('https://api.kawalcorona.com/indonesia/');
          $nasional = json_decode($datad, true);
         ?>
        <div class="row counters">

          <?php    
            foreach ($nasional as $nsn) :
          ?>

          <div class="col-lg-3 col-6 text-center idn">
            <span class="warna">Indonesia</span>
          </div>

          <div class="col-lg-3 col-6 text-center">
            <span data-toggle="counter-up"><?= $nsn['positif']; ?></span>
            <p>Positif</p>
          </div>

          <div class="col-lg-3 col-6 text-center">
            <span data-toggle="counter-up"><?= $nsn['sembuh']; ?></span>
            <p>Sembuh</p>
          </div>

          <div class="col-lg-3 col-6 text-center">
            <span data-toggle="counter-up"><?= $nsn['meninggal']; ?></span>
            <p>Meninggal</p>
          </div>

          <?php    
            endforeach;
          ?>

          <div class="col-md-12 pt-3 text-center">
            <a href="datacovid.php" class="btn btn-primary">Lihat Detail <i class="icofont-long-arrow-right"></i></a>
          </div>

        </div>

      </div>
    </section><!-- /.Counts -->

    <!-- ======= Edukasi ======= -->
    <section id="edukasi" class="edukasi section-bg">
      <div class="container" data-aos="fade-up">

        <div class="section-title">
          <h2>GEJALA</h2>
          <p>Berikut gejala-gejala yang terjadi pada penderita COVID-19</p>
        </div>

        <div class="row">
          <div class="col-lg-4 col-md-6 d-flex align-items-stretch" data-aos="zoom-in" data-aos-delay="100">
            <div class="icon-box">
              <div class="icon">
                <img src="assets/img/cor-service-icon-01.png">
              </div>
              <h4><a href="">Sakit Kepala</a></h4>
              <p>Jika sakit kepala Anda tidak disertai gejala infeksi virus corona Covid-19 lain, seperti demam dan batuk. Maka kecil kemungkinannya sakit kepala itu tanda infeksi virus corona Covid-19.</p>
            </div>
          </div>

          <div class="col-lg-4 col-md-6 d-flex align-items-stretch mt-4 mt-md-0" data-aos="zoom-in" data-aos-delay="200">
            <div class="icon-box iconbox-orange ">
              <div class="icon">
                <img src="assets/img/cor-service-icon-02.png">
              </div>
              <h4><a href="">Batuk</a></h4>
              <p> batuk karena gejala Covid-19 sangat menganggu. Batuk kering yang terasa seolah berasal dari sesuatu yang jauh di dalam dada.</p>
            </div>
          </div>

          <div class="col-lg-4 col-md-6 d-flex align-items-stretch mt-4 mt-lg-0" data-aos="zoom-in" data-aos-delay="300">
            <div class="icon-box iconbox-pink">
              <div class="icon">
                <img src="assets/img/cor-service-icon-03.png">
              </div>
              <h4><a href="">Nyeri Tenggorokan</a></h4>
              <p>selama sakit tenggorokan tidak diiringi keluhan lainnya seperti pilek, sesak napas, dan demam, maka Anda tidak perlu khawatir.</p>
            </div>
          </div>

          <div class="col-lg-4 col-md-6 d-flex align-items-stretch mt-4" data-aos="zoom-in" data-aos-delay="100">
            <div class="icon-box iconbox-yellow">
              <div class="icon">
                <img src="assets/img/cor-service-icon-04.png">
              </div>
              <h4><a href="">Demam / Suhu Tinggi</a></h4>
              <p>Salah satu gejala demam yang paling umum adalah suhu tubuh Anda naik di sore dan menjelang petang. Itu adalah cara umum virus menghasilkan demam</p>
            </div>
          </div>

          <div class="col-lg-4 col-md-6 d-flex align-items-stretch mt-4" data-aos="zoom-in" data-aos-delay="200">
            <div class="icon-box iconbox-red">
              <div class="icon">
                <img src="assets/img/cor-service-icon-05.png">
              </div>
              <h4><a href="">Sesak Nafas</a></h4>
              <p>Para ahli mengatakan, saat dada Anda terasa seperti diikat atau mulai merasa kesulitan untuk bernapas, ini adalah tanda Anda harus bertindak cepat</p>
            </div>
          </div>

          <div class="col-lg-4 col-md-6 d-flex align-items-stretch mt-4" data-aos="zoom-in" data-aos-delay="300">
            <div class="icon-box iconbox-teal">
              <div class="icon">
                <img src="assets/img/cor-service-icon-06.png">
              </div>
              <h4><a href="">Badan Sakit</a></h4>
              <p>Seseorang yang terinfeksi virus corona COVID-19 pada pekan pertama akan merasakan sakit yang berlebihan pada otot dan jaringan di sekitarnya</p>
            </div>
          </div>

        </div>

      </div>
    </section><!-- /.Edukasi -->

    <!-- ======= Pencegahan ======= -->
    <section id="pencegahan" class="pencegahan">
      <div class="container" data-aos="fade-up">

        <div class="section-title">
          <h2 class="text-white">PENCEGAHAN</h2>
          <p class="text-white">Berikut pencegahan COVID-19 yang dapat kita lakukan</p>
        </div>

        <div class="row">
          <div class="col-lg-6 order-2 order-lg-1 d-flex flex-column align-items-lg-center">
            <div class="icon-box mt-5 mt-lg-0" data-aos="fade-up" data-aos-delay="100">
              <i class="bx bx-home"></i>
              <h4>Diam Di Rumah</h4>
              <p class="text-white"><b>Tetap tinggal dirumah jika memang tidak ada kepentingan mendesak untuk keluar</b></p>
            </div>
            <div class="icon-box mt-2" data-aos="fade-up" data-aos-delay="200">
              <i class="bx bx-donate-blood"></i>
              <h4>Cuci Tangan</h4>
              <p class="text-white"><b>Cuci tangan dengan sabun dan air minimal 20 detik atau gunakan hand sanitizer berbasis alkohol minimal 60 %</b></p>
            </div>
            <div class="icon-box mt-2" data-aos="fade-up" data-aos-delay="300">
              <i class="bx bx-run"></i>
              <h4>Olahraga</h4>
              <p class="text-white"><b>Rajinlah berolahraga secara rutin dan teratur, pilihlah olahraga yang disukai, bisa juga diiringi dengan musik yang disukai</b></p>
            </div>
            <div class="icon-box mt-2" data-aos="fade-up" data-aos-delay="400">
              <i class="bx bx-shield-x"></i>
              <h4>Pakai Masker</h4>
              <p class="text-white"><b>Pakailah masker jika kita mempunyai kebutuhan mendesak untuk keluar rumah</b></p>
            </div>
          </div>
          <div class="image col-lg-6 order-1 order-lg-2 " data-aos="zoom-in" data-aos-delay="100">
            <img src="assets/img/cor-about.png" alt="" class="img-fluid">
          </div>
        </div>

      </div>
    </section><!-- /.pencegahan -->

    <!-- ======= Donasi ======= -->
    <section id="donasi" class="donasi section-bg text-center">
      <div class="container text-center" data-aos="fade-up">
        <div class="row text-center">
        <div class="col-lg-12 col-md-12 d-flex align-items-stretch" data-aos="zoom-in" data-aos-delay="100">
          <div class="icon-box iconbox-blue">
            <div class="row">
              <div class="col-md-3">
                <i class="bx bx-donate-heart"></i>
              </div>
              <div class="col-md-6">
                <p>
                  <b>
                    Dengan berdonasi, anda telah menjadi pahlawan di masa pandemik COVID-19 ini. Mari donasikan sebagian harta kita untuk saudara kita yang terkena wabah COVID-19.
                  </b>
                </p>
              </div>
              <div class="col-md-3">
                <a href="donasicovid.php"><i class="btn btn-primary"><b>Donasi Sekarang</b></i></a>
              </div>
            </div>
          </div>
        </div>
        </div>
      </div>
    </section><!-- /.donasi -->

    <!-- ======= Frequently Asked Questions Section ======= -->
    <section id="faq" class="faq">
      <div class="container" data-aos="fade-up">

        <div class="section-title">
          <h2>Frequently Asked Questions</h2>
          <p>FAQ (Frequently Asked Questions) Terkait Virus Corona (COVID-19)</p>
        </div>
        <div class="row">
        <div class="col-md-6">
            <div class="faq-list">
              <ul>
                <li data-aos="fade-up" data-aos-delay="100">
                  <i class="bx bx-help-circle icon-help"></i> <a data-toggle="collapse" class="collapsed" href="#faq-list-1">Apa itu virus corona ? <i class="bx bx-chevron-down icon-show"></i><i class="bx bx-chevron-up icon-close"></i></a>
                  <div id="faq-list-1" class="collapse" data-parent=".faq-list">
                    <p style="text-align: justify;">
                      Virus korona adalah sebutan untuk jenis virus yang dapat menyebabkan penyakit pada hewan dan manusia. Disebut korona karena bentuknya yang seperti mahkota (korona ~ crown = mahkota dalam bahasa Latin). 
                      Beberapa contoh penyakit pada manusia yang disebabkan oleh virus korona antara lain MERS (Sindrom Pernafasan Timur Tengah) dan SARS (Sindrom Pernafasan Akut Parah). 
                      Virus korona terbaru yang ditemukan yang ditemukan di Wuhan, Tiongkok, pada bulan Desember 2019 diberi nama SARS Coronavirus 2 (SARS-CoV-2) dan menyebabkan penyakit Coronavirus Disease 2019 (COVID-19).
                      <br><br>
                      Sumber :
                      <a href="https://www.who.int/news-room/q-a-detail/q-a-coronaviruses" style="font-size: 12px;" class="ml-0 pl-0" target="_BLANK">https://www.who.int/news-room/q-a-detail/q-a-coronaviruses</a>
                    </p>
                  </div>
                </li>

                <li data-aos="fade-up" data-aos-delay="200">
                  <i class="bx bx-help-circle icon-help"></i> <a data-toggle="collapse" href="#faq-list-2" class="collapsed">Apa bedanya dengan COVID-19 ? <i class="bx bx-chevron-down icon-show"></i><i class="bx bx-chevron-up icon-close"></i></a>
                  <div id="faq-list-2" class="collapse" data-parent=".faq-list">
                    <p style="text-align: justify;">
                      COVID-19 adalah penyakit menular yang disebabkan oleh virus korona SARS-CoV-2. Dengan kata lain, SARS-CoV-2 adalah nama virusnya, sementara COVID-19 adalah nama penyakitnya. Ini seperti HIV yang adalah nama virus dari penyakit AIDS.
                      <br><br>
                      Sumber :
                      <a href="https://www.who.int/news-room/q-a-detail/q-a-coronaviruses" style="font-size: 12px;" class="ml-0 pl-0" target="_blank">https://www.who.int/news-room/q-a-detail/q-a-coronaviruses</a>
                    </p>
                  </div>
                </li>

                <li data-aos="fade-up" data-aos-delay="300">
                  <i class="bx bx-help-circle icon-help"></i> <a data-toggle="collapse" href="#faq-list-3" class="collapsed">Jika seseorang terinfeksi virus ini, berapa lama sampai muncul gejala? <i class="bx bx-chevron-down icon-show"></i><i class="bx bx-chevron-up icon-close"></i></a>
                  <div id="faq-list-3" class="collapse" data-parent=".faq-list">
                    <p style="text-align: justify;">
                      Masa inkubasi (dari masuknya virus ke dalam tubuh sampai munculnya gejala awal) adalah 1 – 14 hari, dengan rata-rata timbulnya gejala selama 5 hari.
                      <br><br>
                      Sumber :
                      <a href="https://www.who.int/news-room/q-a-detail/q-a-coronaviruses" style="font-size: 12px;" class="ml-0 pl-0" target="_blank">https://www.who.int/news-room/q-a-detail/q-a-coronaviruses</a>
                    </p>
                  </div>
                </li>

                <li data-aos="fade-up" data-aos-delay="400">
                  <i class="bx bx-help-circle icon-help"></i> <a data-toggle="collapse" href="#faq-list-4" class="collapsed">Bagaimanakah tingkat kematian akibat penyakit ini jika dilihat dari ada/tidak adanya penyakit penyerta/komorbiditas lainnya? <i class="bx bx-chevron-down icon-show"></i><i class="bx bx-chevron-up icon-close"></i></a>
                  <div id="faq-list-4" class="collapse" data-parent=".faq-list">
                    <p style="text-align: justify;">
                      Berdasarkan data yang sama, tingkat kematian akibat penyakit ini jika pasien tersebut memiliki penyakit penyerta lainnya adalah: <br>

                      1. Kondisi tanpa penyakit penyerta apapun: 0,9% <br>
                      2. Pasien dengan penyakit kardiovaskular: 10,5% <br>
                      3. Diabetes: 7,3% <br>
                      4. Saluran pernapasan kronis: 6,3% <br>
                      5. Tekanan darah tinggi: 6% <br>
                      6. Kanker: 5,6%
                      <br><br>
                      Sumber :
                      <p>Bahasa Mandarin:<a href="http://html.rhhz.net/zhlxbx/004.htm#zz" style="font-size: 12px;" class="ml-0 pl-0" target="_blank"> http://html.rhhz.net/zhlxbx/004.htm#zz</a></p>
                      <p>Bahasa Inggris:<a href=" https://jamanetwork.com/journals/jama/fullarticle/2762130" style="font-size: 12px;" class="ml-0 pl-0" target="_blank">  https://jamanetwork.com/journals/jama/fullarticle/2762130</a></p>
                    </p>
                  </div>
                </li>
              </ul>
            </div>
          </div>

          <div class="col-md-6">
            <div class="faq-list">
              <ul>
                <li data-aos="fade-up" data-aos-delay="200">
                  <i class="bx bx-help-circle icon-help"></i> <a data-toggle="collapse" href="#faq-list-a" class="collapsed">Bagaimana COVID-19 menular ? <i class="bx bx-chevron-down icon-show"></i><i class="bx bx-chevron-up icon-close"></i></a>
                  <div id="faq-list-a" class="collapse" data-parent=".faq-list">
                    <p style="text-align: justify;">
                      Penularan terjadi melalui droplet (butir-butir tetesan cairan) dari hidung atau mulut yang menyebar saat pembawa virus COVID-19 batuk, bersin atau meler. Tetesan cairan tersebut akan menempel pada benda atau permukaan di sekitarnya. Dan kemudian masuk ke mulut, hidung atau mata. Atau menyentuh permukaan bekas terkena butir cairannya dengan tangan lalu tangan mengusap mulut, hidung atau mata. Inilah alasan pentingnya sering-sering cuci tangan dan jangan menyentuh muka dengan tangan.
                      Orang sehat dapat tertular saat tangan mereka menyentuh permukaan yang terkena tetesan tersebut dan kemudian tanpa sadar menyentuh mata, mulut, ataupun hidung (selaput lendir). Virus juga bisa masuk saat orang sehat secara tidak sengaja menghirup tetesan cairan saat si pembawa virus batuk atau bersin.
                    </p>
                  </div>
                </li>

                <li data-aos="fade-up" data-aos-delay="200">
                  <i class="bx bx-help-circle icon-help"></i> <a data-toggle="collapse" href="#faq-list-b" class="collapsed">Berapa lama tetesan cairan berisi virus itu bisa hidup di permukaan atau menempel pada benda? <i class="bx bx-chevron-down icon-show"></i><i class="bx bx-chevron-up icon-close"></i></a>
                  <div id="faq-list-b" class="collapse" data-parent=".faq-list">
                    <p style="text-align: justify;">
                      Masih belum pasti berapa lama virus ini dapat bertahan di permukaan, tetapi tampaknya virus ini memiliki karakteristik yang sama dengan virus korona lainnya. Studi menunjukkan bahwa virus korona (termasuk beberapa informasi awal tentang COVID-19) dapat bertahan selama beberapa jam di permukaan. Ini dapat bervariasi di dalam kondisi yang berbeda (mis. jenis permukaan, suhu atau kelembaban lingkungan). Tetapi sabun maupun cairan disinfektan sederhana dapat membunuhnya.
                      <br><br>
                      Sumber :
                      <a href="https://www.who.int/news-room/q-a-detail/q-a-coronaviruses" style="font-size: 12px;" class="ml-0 pl-0" target="_blank">https://www.who.int/news-room/q-a-detail/q-a-coronaviruses</a>
                    </p>
                  </div>
                </li>

                <li data-aos="fade-up" data-aos-delay="300">
                  <i class="bx bx-help-circle icon-help"></i> <a data-toggle="collapse" href="#faq-list-c" class="collapsed">Seberapa banyak pasien yang akan mengalami gejala serius? <i class="bx bx-chevron-down icon-show"></i><i class="bx bx-chevron-up icon-close"></i></a>
                  <div id="faq-list-c" class="collapse" data-parent=".faq-list">
                    <p style="text-align: justify;">
                      Dari data yang tersedia saat ini, kita belum bisa menyimpulkan secara persis seberapa parah wabah COVID-19 ini. Tingkat keparahan dan mortalitas suatu wabah juga akan sangat tergantung pada kapasitas sistem kesehatan publik setempat dalam menangani kasus yang ada. Namun, temuan awal mengindikasikan bahwa tingkat keparahan COVID-19 lebih rendah dibandingkan SARS. Berdasarkan data dari 44 ribu pasien yang dirilis oleh Centre of Disease Control di Tiongkok, proporsi pasien dengan gejala ringan/serius/kritis dan tingkat kematiannya adalah sebagai berikut:
                      <ul style="text-align: justify;">
                        1. Gejala ringan seperti flu biasa: 81% (tingkat kematian: 0)<br>
                        2. Gejala lebih serius seperti sesak napas dan pneumonia (radang paru-paru): 14% (tingkat kematian: 0)<br>
                        3. Perlu masuk ICU dengan kondisi kritis karena gagal pernapasan, syok septik, dan gagal multi-organ: 5% (tingkat kematian: 50%)
                      </ul>
                      <br><br>
                      Sumber :
                      <p>Bahasa Mandarin:<a href="http://html.rhhz.net/zhlxbx/004.htm#zz" style="font-size: 12px;" class="ml-0 pl-0" target="_blank"> http://html.rhhz.net/zhlxbx/004.htm#zz</a></p>
                      <p>Bahasa Inggris:<a href=" https://jamanetwork.com/journals/jama/fullarticle/2762130" style="font-size: 12px;" class="ml-0 pl-0" target="_blank">  https://jamanetwork.com/journals/jama/fullarticle/2762130</a></p>
                    </p>
                  </div>
                </li>

                <li data-aos="fade-up" data-aos-delay="400">
                  <i class="bx bx-help-circle icon-help"></i> <a data-toggle="collapse" href="#faq-list-d" class="collapsed">Apa yang harus saya sampaikan kepada tenaga medis jika saya batuk pilek demam dan sulit bernafas? <i class="bx bx-chevron-down icon-show"></i><i class="bx bx-chevron-up icon-close"></i></a>
                  <div id="faq-list-d" class="collapse" data-parent=".faq-list">
                    <p style="text-align: justify;">
                      1. Riwayat perjalanan (jika ada, ke Tiongkok atau negara-negara yang sudah terjangkit COVID-19, seperti Singapura, Jepang, Korea Selatan, dan Italia)  <br> 
                      2. Kapan gejala mulai timbul  <br>
                      3. Adakah kontak selama 14 hari terakhir dengan seseorang yang memiliki gejala pernapasan dan baru datang dari salah satu daerah yang ditemukan memiliki kasus COVID-19
                      <br>
                    </p>
                  </div>
                </li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </section><!-- ./Frequently Asked Questions Section -->

    <!-- ======= Contact Section ======= -->
    <section id="contact" class="contact section-bg">
      <div class="container" data-aos="fade-up">
        <div class="section-title">
          <h2>Contact</h2>
          <p>Berikut adalah Nomor Hotline yang disediakan pemerintah pusat yang bisa kita gunakan</p>
        </div>
        <div class="col-lg-12 col-md-12">
            <div class="info-box mb-4">
              <i class="bx bx-building-house"></i>
              <h3 class="pl-1 pr-1">Daftar 100 Rumah sakit rujukan penanganan COVID-19</h3>
              <p><a href="https://www.kompas.com/tren/read/2020/03/03/183500265/infografik-daftar-100-rumah-sakit-rujukan-penanganan-virus-corona" target="_blank">Kompas.com</a></p>
            </div>
        </div>
        <div class="row">
          <div class="col-lg-3 col-md-6">
            <div class="info-box mb-4">
              <i class="bx bx-map"></i>
              <h3>Website</h3>
              <p><a href="https://infeksiemerging.kemkes.go.id/" target="_blank">infeksiemerging.kemkes.go.id</a></p>
            </div>
          </div>

          <div class="col-lg-3 col-md-6">
            <div class="info-box mb-4">
              <i class="bx bx-phone-outgoing"></i>
              <h3>Nomor Hotline</h3>
              <p><a href="tel:081212123119">081212123119</a></p>
            </div>
          </div>

          <div class="col-lg-3 col-md-6">
            <div class="info-box  mb-4">
              <i class="bx bx-phone"></i>
              <h3>Nomor Hotline</h3>
              <p><a href="tel:119">119</a></p>
            </div>
          </div>

          <div class="col-lg-3 col-md-6">
            <div class="info-box  mb-4">
              <i class="bx bx-phone-call"></i>
              <h3>Nomor Hotline</h3>
              <p><a href="tel:0215210411">0215210411</a></p>
            </div>
          </div>
        </div>

        <div class="row">

          <div class="col-lg-6 ">
            <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3960.661827627802!2d107.71577091438714!3d-6.93096236976851!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x2e68dd42c254a55d%3A0xee52343f78dc2e32!2sUIN%20Sunan%20Gunung%20Djati%20Bandung!5e0!3m2!1sid!2sid!4v1591624834597!5m2!1sid!2sid" width="100%" height="450" frameborder="0" style="border:0;" allowfullscreen="" aria-hidden="false" tabindex="0"></iframe>
          </div>

          <div class="col-lg-6 php-email-form">
            <form action="kirimkotaksaran.php" method="post">
              <div class="form-row">
                <div class="col-md-6 form-group">
                  <input type="text" name="nama" class="form-control" id="name" placeholder="Your Name" data-rule="minlen:4" data-msg="Please enter at least 4 chars" style="border-radius: 50px;"/>
                  <div class="validate"></div>
                </div>
                <div class="col-md-6 form-group">
                  <input type="email" class="form-control" name="email" id="email" placeholder="Your Email" data-rule="email" data-msg="Please enter a valid email" style="border-radius: 50px;" />
                  <div class="validate"></div>
                </div>
              </div>
              <div class="form-group">
                <textarea class="form-control" name="pesan" rows="5" data-rule="required" data-msg="Please write something for us" placeholder="Message"></textarea>
                <div class="validate"></div>
              </div>
              <div class="form-group">
                <img src="captcha.php" style="border: 2px solid #2ba3af;padding-top: 0px;">
              </div>
              <div class="form-group">
                <input type="text" id="captcha" name="captcha" class="form-control" style="border-radius: 50px;" placeholder="Enter captcha code">
              </div>
              <div class="text-right"><button type="submit" name="kirim">Send Message</button></div>
            </form>
          </div>
        </div>
      </div>
    </section><!-- End Contact Section -->

  </main><!-- End #main -->

  <!-- ======= Footer ======= -->
  <footer id="footer">

    <div class="container">

      <div class="copyright-wrap d-md-flex py-4">
        <div class="mr-md-auto text-center text-md-left">
          <div class="copyright">
            <img src="assets/img/logo1.png" alt="simona" class="img-fluid" width="190px;">
          </div>
        </div>
        <div class="mr-md-auto text-center text-md-center mt-2">
          <div class="copyright">
            &copy; Copyright <strong><span>SIMONA</span></strong>. All Rights Reserved
          </div>
          <div class="credits">
            Designed by <a href="https://instagram.com/uzifru">UZIFRU</a>
          </div>
        </div>
        <div class="social-links text-center text-md-right pt-3 pt-md-0">
          <a href="https://twitter.com/uzifru1" target="_BLANK" class="twitter">
            <i class="bx bxl-twitter"></i>
          </a>
          <a href="https://facebook.com/uzifru.on" target="_BLANK" class="facebook">
            <i class="bx bxl-facebook"></i>
          </a>
          <a href="https://instagram.com/uzifru" target="_BLANK" class="instagram">
            <i class="bx bxl-instagram"></i>
          </a>
          <a href="https://api.whatsapp.com/send?phone=682217459587&text=Assalamualaikum%20Fauzi" target="_blank" class="google-plus">
            <i class="bx bxl-whatsapp"></i>
          </a>
          <a href="https://www.linkedin.com/in/fauzi-rizky-utama-82473a19a/" target="_BLANK" class="linkedin">
            <i class="bx bxl-linkedin"></i>
          </a>
        </div>
      </div>
    </div>
  </footer><!-- End Footer -->

  <a href="#" class="back-to-top"><i class="icofont-simple-up"></i></a>
  
  <div class="preloader">
    <div class="loading">
      <img src="assets/img/1.gif" width="400">
    </div>
  </div>

  <!-- Vendor JS Files -->
  <script src="assets/vendor/jquery/jquery.min.js"></script>
  <script>
    $(document).ready(function(){
      $(".preloader").delay(400).fadeOut("slow");
    })
  </script>
  <script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="assets/vendor/jquery.easing/jquery.easing.min.js"></script>
  <script src="assets/vendor/php-email-form/validate.js"></script>
  <script src="assets/vendor/waypoints/jquery.waypoints.min.js"></script>
  <script src="assets/vendor/counterup/counterup.min.js"></script>
  <script src="assets/vendor/owl.carousel/owl.carousel.min.js"></script>
  <script src="assets/vendor/isotope-layout/isotope.pkgd.min.js"></script>
  <script src="assets/vendor/venobox/venobox.min.js"></script>
  <script src="assets/vendor/aos/aos.js"></script>

  <!-- Template Main JS File -->
  <script src="assets/js/main.js"></script>

</body>
</html>