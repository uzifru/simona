<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">

  <title>Data Covid-19 SIMONA</title>
  <meta content="" name="descriptison">

  <!-- Favicons -->
  <link href="assets/img/fav.png" rel="icon">
  <link href="assets/img/favicon1.png" rel="apple-touch-icon">

  <!-- Google Fonts -->
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Roboto:300,300i,400,400i,500,500i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">

  <!-- Vendor CSS Files -->
  <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/vendor/icofont/icofont.min.css" rel="stylesheet">
  <link href="assets/vendor/boxicons/css/boxicons.min.css" rel="stylesheet">
  <link href="assets/vendor/owl.carousel/assets/owl.carousel.min.css" rel="stylesheet">
  <link href="assets/vendor/venobox/venobox.css" rel="stylesheet">
  <link href="assets/vendor/aos/aos.css" rel="stylesheet">

  <!-- Template Main CSS File -->
  <link href="assets/css/style.css" rel="stylesheet">
</head>
<body>

  <!-- ======= Header ======= -->
  <header id="header" class="fixed-top header-inner-pages">
    <div class="container-fluid">
      <div class="row justify-content-center">
        <div class="col-xl-9 d-flex align-items-center">
          <a href="index.html" class="logo mr-auto">
            <img src="assets/img/logo1.png" alt="" class="img-fluid">
          </a>
          <!-- Nav menu -->
          <nav class="nav-menu d-none d-lg-block">
            <ul>
              <li><a href="index.php">Home</a></li>
              <li><a href="donasicovid.php">Donasi</a></li>
            </ul>
          </nav><!-- .nav-menu -->
          <a href="petacovid.php" id="fs"  class="get-started-btn">
            <i class="bx bx-map-alt"></i> Lihat Peta
          </a>
      </div>
    </div>
  </header><!-- End Header -->

  <main id="main">

    <!-- ======= Breadcrumbs ======= -->
    <section id="breadcrumbs" class="breadcrumbs">
      <div class="container">
        <div class="d-flex justify-content-between align-items-center">    
          <ol>
            <li><a href="index.php">Home</a></li>
            <li>Data COVID-19</li>
          </ol>
        </div>
      </div>
    </section> <!-- End Breadcrumbs -->

    <section id="portfolio-details" class="portfolio-details">
      <div class="container" data-aos="fade-up">
        <div class="portfolio-description">
          <div class="row">
            <div class="col-md-12">
              <div class="tabs_inner">
              <ul class="nav nav-tabs" id="myTab" role="tablist">
                <li class="nav-item">
                  <a class="nav-link active" id="home-tab" data-toggle="tab" href="#dunia" role="tab" aria-controls="home" aria-selected="true">Data Dunia</a>
                </li>
                <li class="nav-item">
                  <a class="nav-link" id="profile-tab" data-toggle="tab" href="#nasional" role="tab" aria-controls="profile" aria-selected="false">Data Nasional</a>
                </li>
              </ul>
              <div class="tab-content" id="myTabContent">             
                <div class="tab-pane fade show active mt-5" id="dunia" role="tabpanel" aria-labelledby="home-tab">
                  <div class="container">             
                    
                    <?php
                      $dataa = file_get_contents('https://api.kawalcorona.com/positif');
                      $positif = json_decode($dataa, true);

                      $datab = file_get_contents('https://api.kawalcorona.com/sembuh');
                      $sembuh = json_decode($datab, true);

                      $datac = file_get_contents('https://api.kawalcorona.com/meninggal');
                      $meninggal = json_decode($datac, true);  
                    ?>

                    <div class="row text-center mt-3">
    
                      <div class="col-md-4 mt-2">
                        <div class="card"
                          style="border-top: 2px solid #2ba3af;
                          border-radius: 25px;transition: all ease-in-out 0.3s;
                          box-shadow: 0px 0 25px 0 rgba(0, 0, 0, 0.1);">
                          <h6 class="text-center mt-3">DATA POSITIF</h6>
                          <h3 style="color: #2ba3af;text-align: center;" data-toggle="counter-up">
                            <?= $positif['value']; ?>
                          </h3>
                        </div>
                      </div>
                      <div class="col-md-4 mt-2">
                        <div class="card"
                          style="border-top: 2px solid #2ba3af;
                          border-radius: 25px;transition: all ease-in-out 0.3s;
                          box-shadow: 0px 0 25px 0 rgba(0, 0, 0, 0.1);">
                          <h6 class="text-center mt-3">DATA SEMBUH</h6>
                          <h3 style="color: #2ba3af;text-align: center;" data-toggle="counter-up">
                            <?= $sembuh['value']; ?>
                          </h3>
                        </div>
                      </div>
                      <div class="col-md-4 mt-2">
                        <div class="card"
                          style="border-top: 2px solid #2ba3af;
                          border-radius: 25px;transition: all ease-in-out 0.3s;
                          box-shadow: 0px 0 25px 0 rgba(0, 0, 0, 0.1);">
                          <h6 class="text-center mt-3">DATA MENINGGAL</h6>
                          <h3 style="color: #2ba3af;text-align: center;" data-toggle="counter-up">
                            <?= $meninggal['value']; ?>
                          </h3>
                        </div>
                      </div>
                    </div>

                    <div class="row mt-5">
                      <div class="col-md-12 mt-3">
                        <div class="card"
                          style="border-top: 2px solid #2ba3af;
                          transition: all ease-in-out 0.3s;
                          box-shadow: 0px 0 25px 0 rgba(0, 0, 0, 0.1);width: 100%;overflow: scroll;height: 600px;">

                          <table class="table table-bordered table-striped sticky mt-0 mb-0" style="width: 100%;">  
                            <?php  
                              $datad = file_get_contents('https://api.kawalcorona.com/');
                              $negara = json_decode($datad, true);
                            ?>
                            <thead style="background-image: url('assets/img/coro-faq-bg.jpg');text-align: center">
                              <th style="position: sticky;">No</th>
                              <th style="position: sticky;">Negara</th>
                              <th style="position: sticky;">Jumlah Positif</th>
                              <th style="position: sticky;">Jumlah Sembuh</th>
                              <th style="position: sticky;">Jumlah Meninggal</th>
                            </thead>
                            <tbody>
                              <?php 
                                $a=1;
                                foreach ($negara as $ngr) : 
                              ?>
                              <tr>
                                <td><?= $a++; ?></td>
                                <td><?= $ngr['attributes']['Country_Region']; ?></td>
                                <td><?= number_format($ngr['attributes']['Confirmed']); ?></td>
                                <td><?= number_format($ngr['attributes']['Deaths']); ?></td>
                                <td><?= number_format($ngr['attributes']['Recovered']); ?></td>
                              </tr>
                              <?php endforeach; ?>
                            </tbody>
                          </table>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>

                <div class="tab-pane fade" id="nasional" role="tabpanel" aria-labelledby="profile-tab">
                  <div class="container mt-5">
                    <?php  
                      $data2 = file_get_contents('https://api.kawalcorona.com/indonesia/');
                      $nasional = json_decode($data2, true);
                    ?>
                    <div class="row text-center">
                      <?php    
                        foreach ($nasional as $nsn) :
                      ?>
                      <div class="col-md-4 mt-2">
                        <div class="card"
                          style="border-top: 2px solid #2ba3af;
                          border-radius: 25px;transition: all ease-in-out 0.3s;
                          box-shadow: 0px 0 25px 0 rgba(0, 0, 0, 0.1);">
                          <h6 class="text-center mt-3">DATA POSITIF</h6>
                          <h3 style="color: #2ba3af;text-align: center;" data-toggle="counter-up">
                            <?= $nsn['positif']; ?>
                          </h3>
                        </div>
                      </div>
                      <div class="col-md-4 mt-2">
                        <div class="card"
                          style="border-top: 2px solid #2ba3af;
                          border-radius: 25px;transition: all ease-in-out 0.3s;
                          box-shadow: 0px 0 25px 0 rgba(0, 0, 0, 0.1);">
                          <h6 class="text-center mt-3">DATA SEMBUH</h6>
                          <h3 style="color: #2ba3af;text-align: center;" data-toggle="counter-up">
                            <?= $nsn['sembuh']; ?>
                          </h3>
                        </div>
                      </div>
                      <div class="col-md-4 mt-2">
                        <div class="card"
                          style="border-top: 2px solid #2ba3af;
                          border-radius: 25px;transition: all ease-in-out 0.3s;
                          box-shadow: 0px 0 25px 0 rgba(0, 0, 0, 0.1);">
                          <h6 class="text-center mt-3">DATA MENINGGAL</h6>
                          <h3 style="color: #2ba3af;text-align: center;" data-toggle="counter-up">
                            <?= $nsn['meninggal']; ?>
                          </h3>
                        </div>
                      </div>
                      <?php    
                        endforeach;
                      ?>
                    </div>
                  </div>
                  <div class="row mt-5">
                      <div class="col-md-12 mt-3">
                        <div class="card"
                          style="border-top: 2px solid #2ba3af;
                          transition: all ease-in-out 0.3s;
                          box-shadow: 0px 0 25px 0 rgba(0, 0, 0, 0.1);width: 100%;overflow: scroll;height: 600px;">
                          <table id="corona1" class="table table-bordered table-striped sticky mt-0" style="width: 100%;">
                            <?php  
                              $data3 = file_get_contents('https://api.kawalcorona.com/indonesia/provinsi');
                              $provinsi = json_decode($data3, true);
                            ?>
                            <thead style="background-image: url('assets/img/coro-faq-bg.jpg');text-align: center">
                              <th>No</th>
                              <th>Nama Provinsi</th>
                              <th>Jumlah Positif</th>
                              <th>Jumlah Sembuh</th>
                              <th>Jumlah Meninggal</th>
                            </thead>
                            <tbody>
                              <?php 
                                $a=1;
                                foreach ($provinsi as $prv) : ?>
                              <tr>
                                <td><?= $a++; ?></td>
                                <td><?= $prv['attributes']['Provinsi']; ?></td>
                                <td><?= number_format($prv['attributes']['Kasus_Posi']); ?></td>
                                <td><?= number_format($prv['attributes']['Kasus_Semb']); ?></td>
                                <td><?= number_format($prv['attributes']['Kasus_Meni']); ?></td>
                              </tr>
                            <?php endforeach; ?>
                            </tbody>
                          </table>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>     
      </div>
    </section>

  </main><!-- End #main -->

 <!-- ======= Footer ======= -->
  <footer id="footer">

    <div class="container">

      <div class="copyright-wrap d-md-flex py-4">
        <div class="mr-md-auto text-center text-md-left">
          <div class="copyright">
            <img src="assets/img/logo1.png" alt="simona" class="img-fluid" width="190px;">
          </div>
        </div>
        <div class="mr-md-auto text-center text-md-center mt-2">
          <div class="copyright">
            &copy; Copyright <strong><span>SIMONA</span></strong>. All Rights Reserved
          </div>
          <div class="credits">
            Designed by <a href="https://instagram.com/uzifru">UZIFRU</a>
          </div>
        </div>
        <div class="social-links text-center text-md-right pt-3 pt-md-0">
          <a href="https://twitter.com/uzifru1" target="_BLANK" class="twitter">
            <i class="bx bxl-twitter"></i>
          </a>
          <a href="https://facebook.com/uzifru.on" target="_BLANK" class="facebook">
            <i class="bx bxl-facebook"></i>
          </a>
          <a href="https://instagram.com/uzifru" target="_BLANK" class="instagram">
            <i class="bx bxl-instagram"></i>
          </a>
          <a href="https://api.whatsapp.com/send?phone=682217459587&text=Assalamualaikum%20Fauzi" target="_blank" class="google-plus">
            <i class="bx bxl-whatsapp"></i>
          </a>
          <a href="https://www.linkedin.com/in/fauzi-rizky-utama-82473a19a/" target="_BLANK" class="linkedin">
            <i class="bx bxl-linkedin"></i>
          </a>
        </div>
      </div>

    </div>
  </footer><!-- End Footer -->

  <a href="#" class="back-to-top"><i class="icofont-simple-up"></i></a>
  <div id="preloader"></div>

  <div class="preloader">
    <div class="loading">
      <img src="assets/img/1.gif" width="400">
    </div>
  </div>

  <!-- Vendor JS Files -->
  <script src="assets/vendor/jquery/jquery.min.js"></script>
  <script>
      $(document).ready(function(){
        $(".preloader").delay(400).fadeOut("slow");
      })
    </script>
  <script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="assets/vendor/jquery.easing/jquery.easing.min.js"></script>
  <script src="assets/vendor/php-email-form/validate.js"></script>
  <script src="assets/vendor/waypoints/jquery.waypoints.min.js"></script>
  <script src="assets/vendor/counterup/counterup.min.js"></script>
  <script src="assets/vendor/owl.carousel/owl.carousel.min.js"></script>
  <script src="assets/vendor/isotope-layout/isotope.pkgd.min.js"></script>
  <script src="assets/vendor/venobox/venobox.min.js"></script>
  <script src="assets/vendor/aos/aos.js"></script>

  <!-- Template Main JS File -->
  <script src="assets/js/main.js"></script>

</body>

</html>