<?php
if(!isset($_SESSION)) {
     session_start();
}
if (isset($_SESSION['username']) and ($_SESSION['password'])):
?> <!-- Main content -->
 <section class="content">
      <div class="row">
        <div class="col-xs-12">
          <div class="box">
          <!-- /.box -->
          <div class="box">
            <div class="box-header">
              <h3 class="box-title">KOTAK SARAN</h3>
              <p>Mereka Peduli Pada Anda!</p>
            </div>
            <!-- /.box-header -->
            <div class="box-body table-responsive no-padding">
                <div class="box-body">
                    <?php 
                         $kode = $_GET['kode'];
                         $query =  $con->query("select * from kotak_saran where id = $kode ");
                         $berita = $query->fetch_assoc();
                    ?>
                    <div class="form-group">
                    <label for="judul">Nama</label><br>
                        <?php echo $berita['nama']; ?>
                    </div>
                    <div class="form-group">
                    <label for="judul">Email/No Hp</label><br>
                        <?php echo $berita['email']; ?>
                    </div>
                    <div class="form-group">
                    <label for="judul">Saran</label><br>
                        <?php echo $berita['saran']; ?>
                    </div>
                    <div class="form-group">
                        <button onclick="goBack()" class='btn btn-success'>Kembali</button>
                    </div>
                    <script>
                        function goBack() {
                        window.history.back();
                        }
                    </script>

                </div>
            </div>
            <!-- /.box-body -->
          </div>
          <!-- /.box -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->
    
<?php 
else:
  echo "<script>;window.location=('index.php');</script>"; 
endif;
?>