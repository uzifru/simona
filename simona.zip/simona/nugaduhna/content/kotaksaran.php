<?php
if(!isset($_SESSION)) {
     session_start();
}
if (isset($_SESSION['username']) and ($_SESSION['password'])):
?> <!-- Main content -->
 <section class="content">
      <div class="row">
        <div class="col-xs-12">
          <div class="box">
          <!-- /.box -->
          <div class="box">
            <div class="box-header">
              <h3 class="box-title">KOTAK SARAN</h3>
              <p>Mereka Peduli Pada Anda!</p>
            </div>
            <!-- /.box-header -->
            <div class="box-body table-responsive no-padding">
              <table id="kotaksaran" class="table table-bordered table-striped">
                <thead>
                <tr>
                  <th>No</th>
                  <th>Nama</th>
                  <th>Email</th>
                  <th>Saran</th>
                  <th>Aksi</th>
                </tr>
                </thead>
                <tbody>
                <?php 
                $no=1;
                    $query =  $con->query("select * from kotak_saran");
                    while($berita = $query->fetch_assoc()):
                ?>
                <tr>
                  <td>
                    <?php echo $berita['id'] ?>
                  </td>
                  <td>
                    <?php echo $berita['nama'] ?>
                  </td>
                  <td >
                      <?php echo $berita['email'] ?>
                  </td>
                  <td>
                    <?php 
                      $saran = $berita['saran'];
                      if (strlen($berita['saran']) > 100) $berita['saran'] = substr($berita['saran'], 0, 100) . "..."; 
                      echo $berita['saran'];
                      // echo strlen($deskpendek);
                    ?>
                  </td>
                  <td>
                     <a href="home.php?page=kotaksarandetail&kode=<?php echo $berita['id'];?>"><i class='fa fa fa-eye'> Lihat </i></a>
                     <a href="content/aksi/deletesaran.php?aksi=hapus&id=<?php echo $berita['id']?>"><i class='fa fa-trash'></i></a>
                  </td>
                </tr>
                <?php 
                    endwhile;
                ?>
                </tbody>
                <tfoot>
                <tr>
                  <th>No</th>
                  <th>Nama</th>
                  <th>Email</th>
                  <th>Saran</th>
                  <th>Aksi</th>
                </tr> 
                </tfoot>
              </table>
            </div>
            <!-- /.box-body -->
          </div>
          <!-- /.box -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->
    
<?php 
else:
  echo "<script>;window.location=('index.php');</script>"; 
endif;
?>