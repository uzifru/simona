<script language="JavaScript">
	window.location = "../../index.php";
</script>