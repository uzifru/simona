<?php 
    $konten = @$_GET['page'];
    if($konten == ''):
        include"content/konten.php";

    
    elseif($konten == 'donasi'):
        include"content/donasi.php";

    elseif($konten == 'kotaksaran'):
        include"content/kotaksaran.php";
    elseif($konten == 'kotaksarandetail'):
        include"content/kotaksarandetail.php";
    elseif($konten == 'gantipassword'):
        include"content/gantipassword.php";

    elseif($konten == 'profiladmin'):
        include"content/profiladmin.php";
    else:
        include"content/404.php";
    endif;
?>